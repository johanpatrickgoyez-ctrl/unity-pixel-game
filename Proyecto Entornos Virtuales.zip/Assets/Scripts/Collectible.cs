using UnityEngine;
using TMPro;

public class Collectible : MonoBehaviour
{
    private TextMeshProUGUI counterText;

    private static int count = 0;

    void Start()
    {
        counterText = GameObject.Find("CounterText").GetComponent<TextMeshProUGUI>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            count++;

            counterText.text = "FOTOS RECOGIDAS: " + count + "/5";

            Destroy(gameObject);
        }
    }
}