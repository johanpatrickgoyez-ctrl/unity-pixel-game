using UnityEngine;
using TMPro;

public class Interaction : MonoBehaviour
{
    public GameObject dialoguePanel;
    public TextMeshProUGUI dialogueText;

    private bool playerNear = false;

    void Update()
    {
        if (playerNear && Input.GetKeyDown(KeyCode.E))
        {
            dialoguePanel.SetActive(true);

            dialogueText.text =
            "Bienvenido a la Iglesia de la Compañía de Jesús. Uno de los lugares históricos más importantes de Quito.";
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            dialoguePanel.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerNear = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerNear = false;
            dialoguePanel.SetActive(false);
        }
    }
}