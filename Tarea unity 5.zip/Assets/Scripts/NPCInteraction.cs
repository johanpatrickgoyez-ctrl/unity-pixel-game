using UnityEngine;

public class NPCInteraction : MonoBehaviour
{
    public GameObject npcBubble;

    private bool playerNear = false;

    void Update()
    {
        if (playerNear && Input.GetKeyDown(KeyCode.E))
        {
            npcBubble.SetActive(true);
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            npcBubble.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerNear = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerNear = false;
            npcBubble.SetActive(false);
        }
    }
}